import rsa
import argparse
from typing import Dict

def encrypt_message(recipient: str, message: str, public_keys: Dict[str, rsa.PublicKey]) -> bytes:
    """Encrypts a message for a recipient using their public key."""
    public_key = public_keys[recipient]
    encrypted_message = rsa.encrypt(message.encode(), public_key)
    return encrypted_message

def decrypt_file(filename: str, private_key: rsa.PrivateKey) -> str:
    """Decrypts the contents of a file using a private key."""
    with open(filename, "rb") as file:
        contents = file.read()
    clear_message = rsa.decrypt(contents, private_key)
    return clear_message.decode()

def generate_keys() -> None:
    """Generates a new public-private key pair and saves them to files."""
    public_key, private_key = rsa.newkeys(1024)
    with open("public.pem", "wb") as f:
        f.write(public_key.save_pkcs1("PEM"))
    with open("private.pem", "wb") as f:
        f.write(private_key.save_pkcs1("PEM"))

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Encrypt and decrypt messages using RSA encryption.")
    parser.add_argument("action", choices=["encrypt", "decrypt", "generate_keys"], help="Action to perform.")
    parser.add_argument("--recipient", help="Recipient's name.")
    parser.add_argument("--message", help="Message to encrypt.")
    parser.add_argument("--filename", help="File to decrypt.")
    args = parser.parse_args()

    # Load public and private keys
    with open("public.pem", "rb") as f:
        public_key = rsa.PublicKey.load_pkcs1(f.read())
    with open("private.pem", "rb") as f:
        private_key = rsa.PrivateKey.load_pkcs1(f.read())
    public_keys = {}
    for recipient in ["Richard", "Sherifat", "Martins"]:
        with open(f"publicKey_{recipient}.pem", "rb") as f:
            public_keys[recipient] = rsa.PublicKey.load_pkcs1(f.read())

    # Perform the selected action
    if args.action == "encrypt
